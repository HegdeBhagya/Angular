
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IBooking } from './travel-list.model';
import { TravelRatingComponent } from '../travel-rating/travel-rating.component';
import { BookingService } from './travel.service';


@Component({
  selector: 'app-travel-list',
  templateUrl: './travel-list.component.html',
  styleUrls: ['./travel-list.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule,TravelRatingComponent,RouterModule] 
})
export class TravelListComponent implements OnInit {
  searchTerm: string = ''; 
  

  constructor(private _bookService:BookingService){
 
  }
  ngOnInit():void{
    this.destinations=this._bookService.getBooking();
  }


  destinations: IBooking[] = [];


get filteredDestinations() {
  const searchLower = this.searchTerm?.toLowerCase() || '';

  return this.destinations.filter(destination =>
    destination.name.toLowerCase().startsWith(searchLower) ||  
    destination.location.toLowerCase().startsWith(searchLower) 
  );
}



onRatingClicked(message: string): void {
  alert(message);
}
}