export interface IBooking {
    tourID:number;
    img: string;
    name: string;
    location: string;
    rating: number;
    price: number;
}